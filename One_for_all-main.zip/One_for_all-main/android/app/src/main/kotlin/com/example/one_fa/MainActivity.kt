package com.example.one_fa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
